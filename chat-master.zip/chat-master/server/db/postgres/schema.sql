# The MySQL and PostrgreSQL schemas are identical save for differences in SQL flavors.
# SEE ../mysql/schema.sql.
