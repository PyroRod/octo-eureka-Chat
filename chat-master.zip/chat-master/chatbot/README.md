# Tinode ChatBot Examples

* [Python chatbot](python/)
* [Karuha](https://github.com/Visecy/Karuha) - third party chatbot framework.
* [C# .Net/.NetCore chatbot](https://github.com/tinode/csharpbot)
